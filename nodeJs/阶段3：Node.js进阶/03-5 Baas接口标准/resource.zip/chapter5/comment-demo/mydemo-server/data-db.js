// 模拟数据库数据
module.exports.getData = () => {
  return [{
    lname: '传智播客',
    lurl: 'http://www.itcast.cn/'
  }, {
    lname: '博学谷',
    lurl: 'https://www.boxuegu.com/'
  }, {
    lname: '传智专修学院',
    lurl: 'http://www.czxy.com/'
  }]
}