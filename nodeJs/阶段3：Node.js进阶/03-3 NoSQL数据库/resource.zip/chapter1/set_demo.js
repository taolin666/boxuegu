var redis = require('redis');
var client = new redis({

});

// 存储标签  post:id:comments  post:id:tags

client.sadd('post:42:tags 杂文 技术 java nodejs');  //存储
client.srem('post:42:tags 技术'); 

var tags = client.smember('post:42:tags');

