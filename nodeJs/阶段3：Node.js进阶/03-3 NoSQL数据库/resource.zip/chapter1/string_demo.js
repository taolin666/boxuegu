var redis = require('redis');
var client = new redis({
    // 配置
});

var $post_id = client.incr('post:count');

// 字符串类型, 标题，内容，阅读量  JSON.stringfy
var $airtile = JSON.stringify({
    title: 'hello',
    content: 'xxxx',
    view: 0
});

client.set(`post:${$post_id}:data ${$airtile}`);   // 文章数据的存储


// 读取文章

var airticle1 = client.get('post:1:data');   //airticle1是字符串

var data = JSON.parse(airticle1);

console.log(data.title)


//  递增id
var $post_id = client.incr('post:count')