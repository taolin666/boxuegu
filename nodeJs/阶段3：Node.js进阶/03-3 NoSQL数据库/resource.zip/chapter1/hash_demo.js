var data = {
    a: 1,
    b: 2
}

// a做了一个操作   data.a = 10;
// b 也做了一个操作 data.b = 20;

// "{a: 1, b: 2}"

// a  "{a: 10, b: 2}"
// b  "{a: 1, b: 20}"

var redis = require('redis');
var client = new redis({
    // option
});

var $post_id =  client.incr('post:count');

var $slug = 'hello-world';
var $title = 'hello world';
var content = 'xxxxxxxxxxxxxx';
var $views = 0;

// 存储逻辑
// 生成文章之前，校验缩略名是否可用    hsetnx, 属性存在则修改失败，反之成功
// 用关系性数据库 会额外建一张表来存储  文章的ID  和 缩略名直接的映射关系 。 散列 类型 叫做 slug.to.ld 专门存储 文章的ID  和 缩略名
var isSlug = client.hsetnx(`slug.to.id ${$slug} $post_id`);  // 缩略名和id就能一一对应

if (isSlug === 0) {
    client.exit('缩略名已存在');
} else {  // 散列存储逻辑
    client.hmset(`post:${$post_id} title ${$title} content ${$content} views ${$views}`);
}

// 读取
// 1. 获取id

var postID = client.hget(`slig.to.id ${$slug}`);

if (!postID) {
    client.exit('文章不存在')
} else {
    var post = client.hgetall(`post:${$post_id}`, (err, data) => { //node会封装
        console.log(data);
    });
}

// 修改缩略名

var newSlug = 'xxxxx';
var isSlugExit = client.hsetnx(`slug.to.id ${newSlug} 42`);

if(!isSlugExit) {
    client.exit('缩略名已经存在');
} else {
    var olgSlug = client.hget(`post:42 slug`);  // 先获取旧的
    client.hset(`post:42 slug ${newSlug}`);  // 赋值新的
    
    client.hdel(`slug.to.id ${olgSlug}`);
    
}