var redis = require('redis');
var client = new redis({
    // 配置
});

// 实现点击量排名  post:page.view  
// zadd post:page.view   实现了一个点击量的有序集合

// 1. 排名 前十 2. 需要分页 

var currentPage = 1;  // 当前页面为1
var listLength = 10;

var start = (currentPage - 1) * listLength;
var end = currentPage * listLength - 1; // 0-9

// 一般排名要按降序 
var postID = client.zrevrange(`post:page.view ${start} ${end}`);

postID.forEach((id) => {
    client.hgetall(`post:${id}`, (data) => {
        console.log('data', data)
    })
})

// 按时间排序 
// 有序集合存储 我们的 时间戳