var Redis = require('ioredis');
var redis = new Redis();  // 实例化了一个客户端

// redis.set('foo', 'bar');

// redis.get('foo', function(err, result) { // 第一个参数是err这是nodejs的约定
//     console.log('result', result)
// })

// // redis.del('foo');

// // redis.sadd('set', 1 , 3, 5 ,7);
// redis.sadd('set', [2, 4, 6, 8]);  // 类似apply和call

//  // 需要过期时间
//  redis.set('guoqi', 100, 'EX', 5);
// var pipeline = redis.pipeline();

// pipeline.set('hello', 'world').set('nihao', 'china').exec();

redis.multi().set('shiwu3', 'aaa').set('shiwu4', asdsad).exec();