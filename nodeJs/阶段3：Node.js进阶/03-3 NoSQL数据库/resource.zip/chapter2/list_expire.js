var redis = require('redis');
var client = new redis({
    // 配置
});

// 判断列表的长度， 代表你的访问次数
var listLength = clien.llen('rate:limit:$ip');

if (listLength < 10) {
    clien.lpush(`rate:limit:$ip ${new Date().valueOf()}`); // 存储时间戳
} else{
    var time = clien.lindex(`rate:limit:$ip -1`);
    if (new Date().valueOf() - time < 60 ) { // 当前时间 - 你第一访问的时间（rate:limit:$ip 列表里面最早的时间 ） < 60秒
        clien.exit('不能访问');
    } else {
        clien.lpush(`rate:limit:$ip ${new Date().valueOf()}`);
        clien.ltrim(`rate:limit:$ip 0 9`);
    }
}