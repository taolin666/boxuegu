var redis = require('redis');
var client = new redis({
    // 配置
});

// 关注与被关注

function follow(currentUser, targetUser) {  // 我 关注 你 
    client.sadd(`user:${currentUser}:guanzhu ${targetUser}`);  // 存储  集合 关注列表会添加你   
    client.sadd(`user:${targetUser}:fensi ${currentUser}`);   // 这里报错
}

follow('我', '你');