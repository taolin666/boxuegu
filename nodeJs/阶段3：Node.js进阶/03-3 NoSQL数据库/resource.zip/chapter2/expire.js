var redis = require('redis');
var client = new redis({
    // 配置
});
// 第一次访问，redis有你的字段吗？ 
var isKeyExists = client.exists(`rate:limit:$ip`);

if (isKeyExists) {  // 假设1分钟对多访问10次
    var times = client.incr(`rate:limit:$ip`);
    if (times > 10) {
        client.exit('你不能访问');
    }
} else {
    // 没有访问过的情况
    client.multi();
    client.incr('rate:limit:$ip');    // 假如出现意外，则永远不会设置过期时间
    client.expire('rate:limit:$ip 60');
    client.exec();
}