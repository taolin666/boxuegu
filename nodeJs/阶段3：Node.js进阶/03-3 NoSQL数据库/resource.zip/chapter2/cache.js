var redis = require('redis');
var client = new redis({
    // 配置
});

// 定于一个key  cache:rank
// 1. 获取成绩  2. 如果没有  重新计算缓存 ， 如果有，直接读取，不需要计算
var rank = client.get('cache:rank');

if (rank) {
    // 有， 直接返回
} else {
    var $rank = jisuan();
    client.multi();
    client.set(`cache:rank ${$rank}`);
    client.expire('cache:rank 7200');
    client.exec();
}