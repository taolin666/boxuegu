const MongoClient = require('mongodb').MongoClient;  // 引入库
// const assert = require('assert');

// Connection URL
const url = 'mongodb://localhost:27017';   // mongo默认端口 27017

// Database Name
const dbName = 'myproject';  // 定义数据库的名称  
const client = new MongoClient(url);   // 实例化一个客户端  并且连接数据库

const insertDocuments = function(db, callback) {
  // Get the documents collection
  const collection = db.collection('documents');  //概念：集合  建了一张 documents这样的表
  // Insert some documents
  collection.insertMany([
    {a : 1, b: 2}, {a : 2, b: 2}, {a : 3, b:3}  // 添加3条数据, 字段有2个分别是 a,b
  ], function(err, result) {
    console.log("Inserted 3 documents into the collection");
    callback(result);
  });
}

const selectData = function(db, callback) {
    const collection = db.collection('documents');
    var whereStr = { b: 2 };   // 语法非常的简洁
    collection.find(whereStr).toArray((err, result) => {
        callback(result)
    })
}

const updateData = function(db, callback) {
    const collection = db.collection('documents');

    var whereStr = {
        a: 1
    };
    var updataStr = {
        $set: {
            b: 1
        }
    };

    collection.update(whereStr, updataStr, function() {
        callback();
    });
}

const delData = function(db, callback) {
    const collection = db.collection('documents');
    var whereStr = { a: 1 };
    collection.remove(whereStr, (err, result) => {
        callback(result)
    });
}

// Use connect method to connect to the server
client.connect(function(err) {
  console.log("Connected successfully to server");

  const db = client.db(dbName);  // 创建一个数据库 叫做 myproject 或者链接
// 1. 建表  
//   insertDocuments(db, function() {  // 插入数据
//     client.close();
//   });

//   selectData(db, function(data) {
//     console.log(data);
//     client.close();
//   });

//   updateData(db, function() {
//     client.close();
//   });
  delData(db, function() {
    client.close();
  });
});