setImmediate(() => {
    console.log('2222')
});

console.log('1111')