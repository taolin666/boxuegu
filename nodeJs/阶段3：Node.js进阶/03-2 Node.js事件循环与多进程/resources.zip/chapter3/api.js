console.log(__dirname); //  /chapter
console.log(__filename); //  /chapter/api.js