// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportCsrf = require('../../../app/controller/csrf');
import ExportHome = require('../../../app/controller/home');
import ExportPosts = require('../../../app/controller/posts');
import ExportBaseHttp = require('../../../app/controller/base/http');
import ExportSubUser = require('../../../app/controller/sub/user');

declare module 'egg' {
  interface IController {
    csrf: ExportCsrf;
    home: ExportHome;
    posts: ExportPosts;
    base: {
      http: ExportBaseHttp;
    }
    sub: {
      user: ExportSubUser;
    }
  }
}
