// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportLog = require('../../../app/middleware/log');

declare module 'egg' {
  interface IMiddleware {
    log: typeof ExportLog;
  }
}
