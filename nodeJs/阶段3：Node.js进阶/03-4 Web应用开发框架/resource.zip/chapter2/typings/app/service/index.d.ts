// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportData = require('../../../app/service/data');

declare module 'egg' {
  interface IService {
    data: ExportData;
  }
}
