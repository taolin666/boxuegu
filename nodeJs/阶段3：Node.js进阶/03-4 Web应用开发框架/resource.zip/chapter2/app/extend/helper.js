// 类似util
exports.getData = () => {
    return '我是处理后的时间'
}