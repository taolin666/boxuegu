module.exports = {
    get isIOS() {
        return '你不是ios';
    }
}