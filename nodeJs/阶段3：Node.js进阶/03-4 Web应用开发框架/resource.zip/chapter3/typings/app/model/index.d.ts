// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportPosts = require('../../../app/model/posts');

declare module 'egg' {
  interface IModel {
    Posts: ReturnType<typeof ExportPosts>;
  }
}
