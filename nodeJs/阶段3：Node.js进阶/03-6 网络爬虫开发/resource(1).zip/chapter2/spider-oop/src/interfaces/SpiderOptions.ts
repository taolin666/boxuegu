export default interface SpiderOptions {
  url: string,
  method?: string,
  headers?: object
}